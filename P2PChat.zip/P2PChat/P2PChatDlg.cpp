// P2PChatDlg.cpp : implementation file
//

#include "stdafx.h"
#include "P2PChat.h"
#include "P2PChatDlg.h"
#include "PeerToPeer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CEdit* cb;
CEdit* ip;
CEdit* m;
CEdit* u;

/////////////////////////////////////////////////////////////////////////////
// CP2PChatDlg dialog

CP2PChatDlg::CP2PChatDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CP2PChatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CP2PChatDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CP2PChatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CP2PChatDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CP2PChatDlg, CDialog)
	//{{AFX_MSG_MAP(CP2PChatDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_MESSAGE, OnChangeEdit2)
	ON_WM_TIMER()
	ON_BN_CLICKED(Send, OnSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CP2PChatDlg message handlers

BOOL CP2PChatDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	cb = (CEdit*)GetDlgItem(IDC_CHATBOX);
	ip = (CEdit*)GetDlgItem(IDC_IP);
	m = (CEdit*)GetDlgItem(IDC_MESSAGE);
	u = (CEdit*)GetDlgItem(IDC_USERNAME);

	if (!Connected())
		Connect(6969);
	
	if (Connected())
		Log("Connected to port 6969.");

	SetTimer(0,100,0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CP2PChatDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CP2PChatDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CP2PChatDlg::OnChangeEdit2() 
{
  CString msg;
  std::string adata;

  m->GetWindowText(msg);

  if (msg.GetLength() == 0)
	 return;

  adata = msg;

  if ( (msg.GetLength() == 2) && (adata.find("\r\n") != string::npos) )
  {
	 m->SetWindowText("");
	 return;
  }

  if (adata.find("\r\n") != string::npos)
  {
	 OnSend();;
	 return;
  }

}

void CP2PChatDlg::Log(CString msg)
{
	if (cb)
	{
	 CString log;
	 cb->GetWindowText(log);
	 log +=msg;
	 log += "\r\n";
	 cb->SetWindowText(log);
	}
}

void CP2PChatDlg::LogSL(CString msg)
{
	if (cb)
	{
	 CString log;
	 cb->GetWindowText(log);
	 log +=msg;
	 cb->SetWindowText(log);
	}
}

void CP2PChatDlg::OnTimer(UINT nIDEvent) 
{
	
	if (!Connected())
		return;

	char* msg;

	if (received_timeout(msg,0,1000))
	{
		LogSL(inet_ntoa(ServerNetwork().sin_addr));
		LogSL(">>");
		Log(msg);
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CP2PChatDlg::OnSend() 
{
 CString theip, msg, user;
 CString finaloutput;

 ip->GetWindowText(theip);
 m->GetWindowText(msg);
 u->GetWindowText(user);

 if ( (msg != "") && (user != "") )
 {
	 finaloutput += user;
	 finaloutput += ": ";
	 finaloutput += msg;
	 
	 if (theip == "")
	 {
		if(Reply(finaloutput.GetBuffer(finaloutput.GetLength())))
		{
			Log(finaloutput);
			m->SetWindowText("");
		}
	 }
	else
	{
		if(SendToIp(theip.GetBuffer(theip.GetLength()),finaloutput))
		{
			Log(finaloutput);
			m->SetWindowText("");
		}
	}
 }
 
}
