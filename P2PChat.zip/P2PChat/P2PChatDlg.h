// P2PChatDlg.h : header file
//

#if !defined(AFX_P2PCHATDLG_H__F6B00CA5_7C71_48CF_BCF2_BB58B9403D6F__INCLUDED_)
#define AFX_P2PCHATDLG_H__F6B00CA5_7C71_48CF_BCF2_BB58B9403D6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CP2PChatDlg dialog

class CP2PChatDlg : public CDialog
{
// Construction
public:
	CP2PChatDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CP2PChatDlg)
	enum { IDD = IDD_P2PCHAT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CP2PChatDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CP2PChatDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeEdit2();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void Log(CString msg);
	afx_msg void LogSL(CString msg);
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_P2PCHATDLG_H__F6B00CA5_7C71_48CF_BCF2_BB58B9403D6F__INCLUDED_)
